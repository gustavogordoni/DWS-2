    <?php 
        $titulo = "Início";
        require 'cabecalho.php';
    ?>              
                <p class="display-4">
                    Seja bem vindo a aplicação <strong>"Lojinha"</strong>.
                </p>
                <p class="display-4">
                    Esta é a página inicial.
                </p>

                <hr>
                <h4>Teste de conexão</h4>

    <?php 
        require 'conexao.php';
        require 'rodape.php';?>