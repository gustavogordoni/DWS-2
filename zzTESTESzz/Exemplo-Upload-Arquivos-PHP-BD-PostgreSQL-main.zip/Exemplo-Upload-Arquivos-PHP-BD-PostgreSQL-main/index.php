<?php

header("Location: formulario-ins.php");
?>
