<div class="col-sm-10">
    <br>
    <a class="btn btn-primary" href="formulario-ins.php">
        Formulário de inserção
    </a>
    <a class="btn btn-primary" href="listagem.php">
        Listagem arquivos
    </a>
</div>