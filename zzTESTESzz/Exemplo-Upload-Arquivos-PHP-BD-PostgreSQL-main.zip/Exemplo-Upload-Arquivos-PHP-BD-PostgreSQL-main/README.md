# Exemplo-Upload-Arquivos-PHP-BD-PostgreSQL
Exemplo de Upload de arquivos no banco de dados (salvando a imagem em banco, bytea) usando PHP e PostgreSQL
