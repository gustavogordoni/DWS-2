<div class="col-sm-10">
    <br>
    <a class="btn btn-primary" href="arquivo-form.php">
        Formulário de inserção
    </a>
    <a class="btn btn-default" href="arquivo-listagem.php">
        Listagem arquivos [formato 1]
    </a>
    <a class="btn btn-default" href="arquivo-listagem-2.php">
        Listagem arquivos [formato 2]
    </a>
</div>