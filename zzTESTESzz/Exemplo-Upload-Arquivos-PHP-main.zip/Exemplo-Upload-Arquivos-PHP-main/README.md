# Exemplo-Upload-Arquivos-PHP
 Exemplo de Upload de arquivos no servidor apache (não no BD) usando PHP e MySQL
