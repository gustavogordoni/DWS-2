<?php

header("Location: arquivo-form.php");
?>
